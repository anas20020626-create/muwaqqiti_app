import 'package:flutter/material.dart';

class QuranPage extends StatelessWidget {
  const QuranPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('القرآن الكريم')),
      body: const Center(
        child: Text('صفحة القرآن ستتم إضافتها لاحقاً'),
      ),
    );
  }
}
